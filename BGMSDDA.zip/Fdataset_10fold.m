clc;clear;
warning('off');
tic
dSS = textread('./drug_Data/DiseaseSim.txt');%313*313
A = xlsread('./drug_Data/DiDrA.xls');%313*593
A=A';%593*313
DCS=textread('./drug_Data/DrugSim.txt');%DrugSim,593*593
A_ori=A;%593*313
y_train=WKNKN( A, DCS, dSS, 5, 0.1*4 ); %593*313
dLNS=LNS(y_train',0,80,'regulation2');    %313*313      
DLNS=LNS(y_train,0,10,'regulation2');    %593*593
F_1_ori=two_graph(DLNS,dLNS,A,y_train,0.4,0.1*4);
F_1_ori_ori=F_1_ori;
index=find(A_ori==1);
auc = zeros(1,10);
aupr=zeros(1,10);
for i = 1:10
    i
    indices = crossvalind('Kfold', length(index), 10);
    A = A_ori;
    F_1_ori=F_1_ori_ori;   
    for cv = 1:10
        cv;
        index_2 = find(cv == indices);      
        A(index(index_2)) = 0;        
        y_train_1=WKNKN( A, DCS, dSS, 5, 0.1*4 ); 
        dLNS1=LNS(y_train_1',0,80,'regulation2');    
        DLNS1=LNS(y_train_1,0,10,'regulation2');            
        F_1=two_graph(DLNS1,dLNS1,A,y_train_1,0.4,0.1*4);     
        F_1_ori(index(index_2)) = F_1(index(index_2));
        A = A_ori;
    end
%     F_1_ori=Norma(F_1_ori);
    pre_label_score = F_1_ori(:);
    label_y = A_ori(:);
    auc(i) = roc_1(pre_label_score,label_y,'red');
    aupr(i) =pr_cure(pre_label_score,label_y,'blue');
    auc(i)
end
auc_ave = mean(auc);
auc_std = std(auc);
aupr_ave = mean(aupr);
aupr_std = std(aupr); 
toc



