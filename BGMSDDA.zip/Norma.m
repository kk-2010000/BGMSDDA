function [B] = Norma(A)

 B=1./(1+exp(-A));

end

